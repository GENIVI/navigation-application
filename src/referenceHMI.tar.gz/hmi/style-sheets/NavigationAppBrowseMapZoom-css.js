/* This file is generated */
.pragma library
Qt.include("style-constants.js");

var zoomout=new Object;
zoomout[SOURCE]="../images/zoomout.png";
zoomout[X]=17;
zoomout[Y]=76;
zoomout[WIDTH]=17;
zoomout[HEIGHT]=6;

var zoomin=new Object;
zoomin[SOURCE]="../images/zoomin.png";
zoomin[X]=18;
zoomin[Y]=20;
zoomin[WIDTH]=17;
zoomin[HEIGHT]=13;

var navigation_app_browse_map_zoom_background=new Object;
navigation_app_browse_map_zoom_background[SOURCE]="../images/navigation-app-browse-map-zoom-background.png";
navigation_app_browse_map_zoom_background[X]=0;
navigation_app_browse_map_zoom_background[Y]=0;
navigation_app_browse_map_zoom_background[WIDTH]=64;
navigation_app_browse_map_zoom_background[HEIGHT]=110;

