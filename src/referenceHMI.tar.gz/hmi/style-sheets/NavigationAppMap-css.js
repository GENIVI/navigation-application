/* This file is generated */
.pragma library
Qt.include("style-constants.js");

var backText=new Object;
backText[X]=651;
backText[Y]=422;
backText[WIDTH]=104;
backText[HEIGHT]=44;
backText[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
backText[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
backText[PIXELSIZE]=38;

var back=new Object;
back[SOURCE]="../images/back.png";
back[X]=620;
back[Y]=415;
back[WIDTH]=160;
back[HEIGHT]=60;

var navigation_app_map_background=new Object;
navigation_app_map_background[SOURCE]="../images/navigation-app-map-background.png";
navigation_app_map_background[X]=0;
navigation_app_map_background[Y]=0;
navigation_app_map_background[WIDTH]=800;
navigation_app_map_background[HEIGHT]=480;

