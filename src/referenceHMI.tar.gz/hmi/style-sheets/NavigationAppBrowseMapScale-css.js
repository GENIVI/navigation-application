/* This file is generated */
.pragma library
Qt.include("style-constants.js");

var scaleValue=new Object;
scaleValue[X]=6;
scaleValue[Y]=4;
scaleValue[WIDTH]=35;
scaleValue[HEIGHT]=13;
scaleValue[TEXTCOLOR]=Qt.rgba(0.00, 0.00, 0.00, 1.00);
scaleValue[STYLECOLOR]=Qt.rgba(0.00, 0.00, 0.00, 1.00);
scaleValue[PIXELSIZE]=11;

var scale_bar=new Object;
scale_bar[SOURCE]="../images/scale-bar.png";
scale_bar[X]=57;
scale_bar[Y]=12;
scale_bar[WIDTH]=40;
scale_bar[HEIGHT]=2;

var left=new Object;
left[SOURCE]="../images/left.png";
left[X]=55;
left[Y]=8;
left[WIDTH]=2;
left[HEIGHT]=6;

var right=new Object;
right[SOURCE]="../images/right.png";
right[X]=97;
right[Y]=8;
right[WIDTH]=2;
right[HEIGHT]=6;

var navigation_app_browse_map_scale_background=new Object;
navigation_app_browse_map_scale_background[SOURCE]="../images/navigation-app-browse-map-scale-background.png";
navigation_app_browse_map_scale_background[X]=0;
navigation_app_browse_map_scale_background[Y]=0;
navigation_app_browse_map_scale_background[WIDTH]=110;
navigation_app_browse_map_scale_background[HEIGHT]=20;

