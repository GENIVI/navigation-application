/* This file is generated */
.pragma library
Qt.include("style-constants.js");

var select_search_for_refill_in_top=new Object;
select_search_for_refill_in_top[SOURCE]="../images/select-search-for-refill-in-top.png";
select_search_for_refill_in_top[X]=728;
select_search_for_refill_in_top[Y]=2;
select_search_for_refill_in_top[WIDTH]=60;
select_search_for_refill_in_top[HEIGHT]=60;

var statusValue=new Object;
statusValue[X]=560;
statusValue[Y]=20;
statusValue[WIDTH]=154;
statusValue[HEIGHT]=19;
statusValue[TEXTCOLOR]=Qt.rgba(1.00, 0.00, 0.00, 1.00);
statusValue[STYLECOLOR]=Qt.rgba(1.00, 0.00, 0.00, 1.00);
statusValue[PIXELSIZE]=16;

var time_in_top=new Object;
time_in_top[X]=3;
time_in_top[Y]=18;
time_in_top[WIDTH]=68;
time_in_top[HEIGHT]=28;
time_in_top[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
time_in_top[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
time_in_top[PIXELSIZE]=24;

var navigation_app_browse_map_top_background=new Object;
navigation_app_browse_map_top_background[SOURCE]="../images/navigation-app-browse-map-top-background.png";
navigation_app_browse_map_top_background[X]=0;
navigation_app_browse_map_top_background[Y]=0;
navigation_app_browse_map_top_background[WIDTH]=788;
navigation_app_browse_map_top_background[HEIGHT]=64;

