/* This file is generated */
.pragma library
Qt.include("style-constants.js");

var rotateAntiClockwize=new Object;
rotateAntiClockwize[SOURCE]="../images/rotateAntiClockwize.png";
rotateAntiClockwize[X]=445;
rotateAntiClockwize[Y]=179;
rotateAntiClockwize[WIDTH]=100;
rotateAntiClockwize[HEIGHT]=100;

var rotateClockwize=new Object;
rotateClockwize[SOURCE]="../images/rotateClockwize.png";
rotateClockwize[X]=230;
rotateClockwize[Y]=60;
rotateClockwize[WIDTH]=100;
rotateClockwize[HEIGHT]=100;

var tiltText=new Object;
tiltText[X]=365;
tiltText[Y]=86;
tiltText[WIDTH]=32;
tiltText[HEIGHT]=24;
tiltText[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
tiltText[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
tiltText[PIXELSIZE]=20;

var tiltm=new Object;
tiltm[SOURCE]="../images/tiltm.png";
tiltm[X]=403;
tiltm[Y]=102;
tiltm[WIDTH]=18;
tiltm[HEIGHT]=18;

var tiltp=new Object;
tiltp[SOURCE]="../images/tiltp.png";
tiltp[X]=403;
tiltp[Y]=80;
tiltp[WIDTH]=18;
tiltp[HEIGHT]=18;

var distanceText=new Object;
distanceText[X]=358;
distanceText[Y]=212;
distanceText[WIDTH]=39;
distanceText[HEIGHT]=24;
distanceText[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
distanceText[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
distanceText[PIXELSIZE]=20;

var distancep=new Object;
distancep[SOURCE]="../images/distancep.png";
distancep[X]=403;
distancep[Y]=207;
distancep[WIDTH]=18;
distancep[HEIGHT]=18;

var distancem=new Object;
distancem[SOURCE]="../images/distancem.png";
distancem[X]=403;
distancem[Y]=229;
distancem[WIDTH]=18;
distancem[HEIGHT]=18;

var heightText=new Object;
heightText[X]=331;
heightText[Y]=150;
heightText[WIDTH]=66;
heightText[HEIGHT]=24;
heightText[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
heightText[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
heightText[PIXELSIZE]=20;

var heightm=new Object;
heightm[SOURCE]="../images/heightm.png";
heightm[X]=403;
heightm[Y]=167;
heightm[WIDTH]=18;
heightm[HEIGHT]=18;

var heightp=new Object;
heightp[SOURCE]="../images/heightp.png";
heightp[X]=403;
heightp[Y]=145;
heightp[WIDTH]=18;
heightp[HEIGHT]=18;

var scrollup=new Object;
scrollup[SOURCE]="../images/scrollup.png";
scrollup[X]=373;
scrollup[Y]=28;
scrollup[WIDTH]=40;
scrollup[HEIGHT]=32;

var scrolldown=new Object;
scrolldown[SOURCE]="../images/scrolldown.png";
scrolldown[X]=373;
scrolldown[Y]=271;
scrolldown[WIDTH]=40;
scrolldown[HEIGHT]=33;

var scrollleft=new Object;
scrollleft[SOURCE]="../images/scrollleft.png";
scrollleft[X]=174;
scrollleft[Y]=144;
scrollleft[WIDTH]=34;
scrollleft[HEIGHT]=40;

var scrollright=new Object;
scrollright[SOURCE]="../images/scrollright.png";
scrollright[X]=551;
scrollright[Y]=144;
scrollright[WIDTH]=34;
scrollright[HEIGHT]=40;

var threeDSettings=new Object;
threeDSettings[SOURCE]="../images/threeDSettings.png";
threeDSettings[X]=328;
threeDSettings[Y]=64;
threeDSettings[WIDTH]=107;
threeDSettings[HEIGHT]=200;

var navigation_app_browse_map_scroll_background=new Object;
navigation_app_browse_map_scroll_background[SOURCE]="../images/navigation-app-browse-map-scroll-background.png";
navigation_app_browse_map_scroll_background[X]=-1;
navigation_app_browse_map_scroll_background[Y]=0;
navigation_app_browse_map_scroll_background[WIDTH]=788;
navigation_app_browse_map_scroll_background[HEIGHT]=328;

