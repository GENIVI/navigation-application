/* This file is generated */
.pragma library
Qt.include("style-constants.js");

var restartText=new Object;
restartText[X]=32;
restartText[Y]=135;
restartText[WIDTH]=134;
restartText[HEIGHT]=35;
restartText[TEXTCOLOR]=Qt.rgba(0.00, 0.00, 0.00, 1.00);
restartText[STYLECOLOR]=Qt.rgba(0.00, 0.00, 0.00, 1.00);
restartText[PIXELSIZE]=30;

var restart=new Object;
restart[SOURCE]="../images/restart.png";
restart[X]=13;
restart[Y]=121;
restart[WIDTH]=160;
restart[HEIGHT]=60;

var cancelText=new Object;
cancelText[X]=32;
cancelText[Y]=51;
cancelText[WIDTH]=121;
cancelText[HEIGHT]=35;
cancelText[TEXTCOLOR]=Qt.rgba(0.00, 0.00, 0.00, 1.00);
cancelText[STYLECOLOR]=Qt.rgba(0.00, 0.00, 0.00, 1.00);
cancelText[PIXELSIZE]=30;

var cancel=new Object;
cancel[SOURCE]="../images/cancel.png";
cancel[X]=13;
cancel[Y]=39;
cancel[WIDTH]=160;
cancel[HEIGHT]=60;

var location_input=new Object;
location_input[SOURCE]="../images/location-input.png";
location_input[X]=218;
location_input[Y]=121;
location_input[WIDTH]=60;
location_input[HEIGHT]=60;

var poi=new Object;
poi[SOURCE]="../images/poi.png";
poi[X]=218;
poi[Y]=39;
poi[WIDTH]=60;
poi[HEIGHT]=60;

var exit=new Object;
exit[SOURCE]="../images/exit.png";
exit[X]=3;
exit[Y]=3;
exit[WIDTH]=22;
exit[HEIGHT]=22;

var navigation_app_browse_map_settings_background=new Object;
navigation_app_browse_map_settings_background[SOURCE]="../images/navigation-app-browse-map-settings-background.png";
navigation_app_browse_map_settings_background[X]=0;
navigation_app_browse_map_settings_background[Y]=0;
navigation_app_browse_map_settings_background[WIDTH]=300;
navigation_app_browse_map_settings_background[HEIGHT]=200;

