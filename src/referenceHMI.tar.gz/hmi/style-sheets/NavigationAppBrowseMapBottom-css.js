/* This file is generated */
.pragma library
Qt.include("style-constants.js");

var zoomout=new Object;
zoomout[SOURCE]="../images/zoomout.png";
zoomout[X]=14;
zoomout[Y]=25;
zoomout[WIDTH]=17;
zoomout[HEIGHT]=6;

var calculate_curr=new Object;
calculate_curr[SOURCE]="../images/calculate_curr.png";
calculate_curr[X]=200;
calculate_curr[Y]=2;
calculate_curr[WIDTH]=60;
calculate_curr[HEIGHT]=60;

var zoomin=new Object;
zoomin[SOURCE]="../images/zoomin.png";
zoomin[X]=84;
zoomin[Y]=21;
zoomin[WIDTH]=17;
zoomin[HEIGHT]=13;

var zoomlevel=new Object;
zoomlevel[X]=47;
zoomlevel[Y]=15;
zoomlevel[WIDTH]=13;
zoomlevel[HEIGHT]=24;
zoomlevel[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
zoomlevel[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
zoomlevel[PIXELSIZE]=20;

var menubText=new Object;
menubText[X]=694;
menubText[Y]=13;
menubText[WIDTH]=82;
menubText[HEIGHT]=35;
menubText[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
menubText[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
menubText[PIXELSIZE]=30;

var mapsettings=new Object;
mapsettings[SOURCE]="../images/mapsettings.png";
mapsettings[X]=603;
mapsettings[Y]=2;
mapsettings[WIDTH]=60;
mapsettings[HEIGHT]=60;

var menub=new Object;
menub[SOURCE]="../images/menub.png";
menub[X]=669;
menub[Y]=2;
menub[WIDTH]=123;
menub[HEIGHT]=60;

var currentroad=new Object;
currentroad[X]=268;
currentroad[Y]=10;
currentroad[WIDTH]=332;
currentroad[HEIGHT]=40;
currentroad[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
currentroad[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
currentroad[PIXELSIZE]=34;

var directionnorth=new Object;
directionnorth[SOURCE]="../images/directionnorth.png";
directionnorth[X]=132;
directionnorth[Y]=2;
directionnorth[WIDTH]=60;
directionnorth[HEIGHT]=60;

var directiondestination=new Object;
directiondestination[SOURCE]="../images/directiondestination.png";
directiondestination[X]=132;
directiondestination[Y]=2;
directiondestination[WIDTH]=60;
directiondestination[HEIGHT]=60;

var navigation_app_browse_map_bottom_background=new Object;
navigation_app_browse_map_bottom_background[SOURCE]="../images/navigation-app-browse-map-bottom-background.png";
navigation_app_browse_map_bottom_background[X]=0;
navigation_app_browse_map_bottom_background[Y]=0;
navigation_app_browse_map_bottom_background[WIDTH]=800;
navigation_app_browse_map_bottom_background[HEIGHT]=64;

