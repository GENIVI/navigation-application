/* This file is generated */
.pragma library
Qt.include("style-constants.js");

var calculate_curr=new Object;
calculate_curr[SOURCE]="../images/calculate_curr.png";
calculate_curr[X]=68;
calculate_curr[Y]=2;
calculate_curr[WIDTH]=100;
calculate_curr[HEIGHT]=60;

var settings=new Object;
settings[SOURCE]="../images/settings.png";
settings[X]=515;
settings[Y]=2;
settings[WIDTH]=60;
settings[HEIGHT]=60;

var menubText=new Object;
menubText[X]=610;
menubText[Y]=13;
menubText[WIDTH]=82;
menubText[HEIGHT]=35;
menubText[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
menubText[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
menubText[PIXELSIZE]=30;

var menub=new Object;
menub[SOURCE]="../images/menub.png";
menub[X]=585;
menub[Y]=2;
menub[WIDTH]=123;
menub[HEIGHT]=60;

var gobackCurrent=new Object;
gobackCurrent[SOURCE]="../images/gobackCurrent.png";
gobackCurrent[X]=1;
gobackCurrent[Y]=2;
gobackCurrent[WIDTH]=60;
gobackCurrent[HEIGHT]=60;

var currentroad=new Object;
currentroad[X]=188;
currentroad[Y]=18;
currentroad[WIDTH]=313;
currentroad[HEIGHT]=30;
currentroad[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
currentroad[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
currentroad[PIXELSIZE]=26;

var mapExploration=new Object;
mapExploration[SOURCE]="../images/mapExploration.png";
mapExploration[X]=0;
mapExploration[Y]=2;
mapExploration[WIDTH]=61;
mapExploration[HEIGHT]=60;

var navigation_app_browse_map_bottom_background=new Object;
navigation_app_browse_map_bottom_background[SOURCE]="../images/navigation-app-browse-map-bottom-background.png";
navigation_app_browse_map_bottom_background[X]=0;
navigation_app_browse_map_bottom_background[Y]=0;
navigation_app_browse_map_bottom_background[WIDTH]=708;
navigation_app_browse_map_bottom_background[HEIGHT]=64;

