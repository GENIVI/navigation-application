/* This file is generated */
.pragma library
Qt.include("style-constants.js");

var maneuverBarAdv=new Object;
maneuverBarAdv[SOURCE]="../images/maneuverBarAdv.png";
maneuverBarAdv[X]=104;
maneuverBarAdv[Y]=43;
maneuverBarAdv[WIDTH]=36;
maneuverBarAdv[HEIGHT]=20;

var maneuverBarPre=new Object;
maneuverBarPre[SOURCE]="../images/maneuverBarPre.png";
maneuverBarPre[X]=72;
maneuverBarPre[Y]=43;
maneuverBarPre[WIDTH]=68;
maneuverBarPre[HEIGHT]=20;

var maneuverBarApp=new Object;
maneuverBarApp[SOURCE]="../images/maneuverBarApp.png";
maneuverBarApp[X]=34;
maneuverBarApp[Y]=43;
maneuverBarApp[WIDTH]=106;
maneuverBarApp[HEIGHT]=20;

var maneuverBarCru=new Object;
maneuverBarCru[SOURCE]="../images/maneuverBarCru.png";
maneuverBarCru[X]=4;
maneuverBarCru[Y]=43;
maneuverBarCru[WIDTH]=136;
maneuverBarCru[HEIGHT]=20;

var distancetomaneuverValue=new Object;
distancetomaneuverValue[X]=4;
distancetomaneuverValue[Y]=9;
distancetomaneuverValue[WIDTH]=78;
distancetomaneuverValue[HEIGHT]=24;
distancetomaneuverValue[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
distancetomaneuverValue[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
distancetomaneuverValue[PIXELSIZE]=20;

var maneuverIcon=new Object;
maneuverIcon[SOURCE]="../images/maneuverIcon.png";
maneuverIcon[X]=144;
maneuverIcon[Y]=3;
maneuverIcon[WIDTH]=64;
maneuverIcon[HEIGHT]=64;

var roadaftermaneuverValue=new Object;
roadaftermaneuverValue[X]=4;
roadaftermaneuverValue[Y]=68;
roadaftermaneuverValue[WIDTH]=192;
roadaftermaneuverValue[HEIGHT]=19;
roadaftermaneuverValue[TEXTCOLOR]=Qt.rgba(0.30, 0.53, 0.99, 1.00);
roadaftermaneuverValue[STYLECOLOR]=Qt.rgba(0.30, 0.53, 0.99, 1.00);
roadaftermaneuverValue[PIXELSIZE]=16;

var navigation_app_browse_map_guidance_background=new Object;
navigation_app_browse_map_guidance_background[SOURCE]="../images/navigation-app-browse-map-guidance-background.png";
navigation_app_browse_map_guidance_background[X]=0;
navigation_app_browse_map_guidance_background[Y]=0;
navigation_app_browse_map_guidance_background[WIDTH]=211;
navigation_app_browse_map_guidance_background[HEIGHT]=92;

