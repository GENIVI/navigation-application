/* This file is generated */
.pragma library
Qt.include("style-constants.js");

var distancetodestinationValue=new Object;
distancetodestinationValue[X]=7;
distancetodestinationValue[Y]=105;
distancetodestinationValue[WIDTH]=84;
distancetodestinationValue[HEIGHT]=27;
distancetodestinationValue[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
distancetodestinationValue[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
distancetodestinationValue[PIXELSIZE]=22;

var timeofarrivalValue=new Object;
timeofarrivalValue[X]=2;
timeofarrivalValue[Y]=70;
timeofarrivalValue[WIDTH]=90;
timeofarrivalValue[HEIGHT]=27;
timeofarrivalValue[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
timeofarrivalValue[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
timeofarrivalValue[PIXELSIZE]=22;

var show_maneuver_list=new Object;
show_maneuver_list[SOURCE]="../images/show-maneuver-list.png";
show_maneuver_list[X]=2;
show_maneuver_list[Y]=3;
show_maneuver_list[WIDTH]=80;
show_maneuver_list[HEIGHT]=94;

var navigation_app_browse_map_route_background=new Object;
navigation_app_browse_map_route_background[SOURCE]="../images/navigation-app-browse-map-route-background.png";
navigation_app_browse_map_route_background[X]=0;
navigation_app_browse_map_route_background[Y]=0;
navigation_app_browse_map_route_background[WIDTH]=94;
navigation_app_browse_map_route_background[HEIGHT]=140;

