/* This file is generated */
.pragma library
Qt.include("style-constants.js");

var directionnorth=new Object;
directionnorth[SOURCE]="../images/directionnorth.png";
directionnorth[X]=2;
directionnorth[Y]=2;
directionnorth[WIDTH]=60;
directionnorth[HEIGHT]=60;

var directionThreeD=new Object;
directionThreeD[SOURCE]="../images/directionThreeD.png";
directionThreeD[X]=2;
directionThreeD[Y]=2;
directionThreeD[WIDTH]=60;
directionThreeD[HEIGHT]=60;

var directiondestination=new Object;
directiondestination[SOURCE]="../images/directiondestination.png";
directiondestination[X]=2;
directiondestination[Y]=2;
directiondestination[WIDTH]=60;
directiondestination[HEIGHT]=60;

var navigation_app_browse_map_compass_background=new Object;
navigation_app_browse_map_compass_background[SOURCE]="../images/navigation-app-browse-map-compass-background.png";
navigation_app_browse_map_compass_background[X]=0;
navigation_app_browse_map_compass_background[Y]=0;
navigation_app_browse_map_compass_background[WIDTH]=64;
navigation_app_browse_map_compass_background[HEIGHT]=64;

