/* This file is generated */
.pragma library
Qt.include("style-constants.js");

var backText=new Object;
backText[X]=648;
backText[Y]=422;
backText[WIDTH]=104;
backText[HEIGHT]=44;
backText[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
backText[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
backText[PIXELSIZE]=38;

var back=new Object;
back[SOURCE]="../images/back.png";
back[X]=620;
back[Y]=415;
back[WIDTH]=160;
back[HEIGHT]=60;

var select_display_on_map=new Object;
select_display_on_map[SOURCE]="../images/select-display-on-map.png";
select_display_on_map[X]=89;
select_display_on_map[Y]=415;
select_display_on_map[WIDTH]=100;
select_display_on_map[HEIGHT]=60;

var select_reroute=new Object;
select_reroute[SOURCE]="../images/select-reroute.png";
select_reroute[X]=199;
select_reroute[Y]=415;
select_reroute[WIDTH]=100;
select_reroute[HEIGHT]=60;

var searchResultValue=new Object;
searchResultValue[X]=553;
searchResultValue[Y]=41;
searchResultValue[WIDTH]=210;
searchResultValue[HEIGHT]=24;
searchResultValue[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
searchResultValue[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
searchResultValue[PIXELSIZE]=20;

var searchResultList=new Object;
searchResultList[SOURCE]="../images/searchResultList.png";
searchResultList[X]=548;
searchResultList[Y]=33;
searchResultList[WIDTH]=220;
searchResultList[HEIGHT]=175;

var categoryKeyboard=new Object;
categoryKeyboard[SOURCE]="../images/categoryKeyboard.png";
categoryKeyboard[X]=29;
categoryKeyboard[Y]=118;
categoryKeyboard[WIDTH]=40;
categoryKeyboard[HEIGHT]=30;

var categoryFrame=new Object;
categoryFrame[SOURCE]="../images/categoryFrame.png";
categoryFrame[X]=73;
categoryFrame[Y]=116;
categoryFrame[WIDTH]=281;
categoryFrame[HEIGHT]=34;

var poiName=new Object;
poiName[X]=101;
poiName[Y]=34;
poiName[WIDTH]=190;
poiName[HEIGHT]=66;
poiName[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
poiName[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
poiName[PIXELSIZE]=28;

var categoryValue=new Object;
categoryValue[X]=75;
categoryValue[Y]=120;
categoryValue[WIDTH]=247;
categoryValue[HEIGHT]=33;
categoryValue[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
categoryValue[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
categoryValue[PIXELSIZE]=28;

var poiKeyboard=new Object;
poiKeyboard[SOURCE]="../images/poiKeyboard.png";
poiKeyboard[X]=29;
poiKeyboard[Y]=171;
poiKeyboard[WIDTH]=40;
poiKeyboard[HEIGHT]=30;

var poiFrame=new Object;
poiFrame[SOURCE]="../images/poiFrame.png";
poiFrame[X]=73;
poiFrame[Y]=168;
poiFrame[WIDTH]=281;
poiFrame[HEIGHT]=34;

var location_input=new Object;
location_input[SOURCE]="../images/location-input.png";
location_input[X]=20;
location_input[Y]=415;
location_input[WIDTH]=60;
location_input[HEIGHT]=60;

var searchResultNumber=new Object;
searchResultNumber[X]=424;
searchResultNumber[Y]=156;
searchResultNumber[WIDTH]=45;
searchResultNumber[HEIGHT]=33;
searchResultNumber[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
searchResultNumber[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
searchResultNumber[PIXELSIZE]=28;

var poiValue=new Object;
poiValue[X]=75;
poiValue[Y]=172;
poiValue[WIDTH]=247;
poiValue[HEIGHT]=33;
poiValue[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
poiValue[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
poiValue[PIXELSIZE]=28;

var selectedValueTitle=new Object;
selectedValueTitle[X]=384;
selectedValueTitle[Y]=158;
selectedValueTitle[WIDTH]=129;
selectedValueTitle[HEIGHT]=29;
selectedValueTitle[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
selectedValueTitle[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
selectedValueTitle[PIXELSIZE]=25;

var selectedValue=new Object;
selectedValue[X]=365;
selectedValue[Y]=32;
selectedValue[WIDTH]=165;
selectedValue[HEIGHT]=100;
selectedValue[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
selectedValue[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
selectedValue[PIXELSIZE]=21;

var settings=new Object;
settings[SOURCE]="../images/settings.png";
settings[X]=542;
settings[Y]=415;
settings[WIDTH]=60;
settings[HEIGHT]=60;

var keyboardArea=new Object;
keyboardArea[SOURCE]="../images/keyboardArea.png";
keyboardArea[X]=28;
keyboardArea[Y]=214;
keyboardArea[WIDTH]=744;
keyboardArea[HEIGHT]=188;

var navigation_app_poi_background=new Object;
navigation_app_poi_background[SOURCE]="../images/navigation-app-poi-background.png";
navigation_app_poi_background[X]=0;
navigation_app_poi_background[Y]=0;
navigation_app_poi_background[WIDTH]=800;
navigation_app_poi_background[HEIGHT]=480;

