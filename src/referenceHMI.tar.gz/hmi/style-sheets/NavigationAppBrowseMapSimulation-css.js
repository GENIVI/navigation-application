/* This file is generated */
.pragma library
Qt.include("style-constants.js");

var speedValue_popup=new Object;
speedValue_popup[X]=36;
speedValue_popup[Y]=12;
speedValue_popup[WIDTH]=35;
speedValue_popup[HEIGHT]=24;
speedValue_popup[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
speedValue_popup[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
speedValue_popup[PIXELSIZE]=20;

var speed_up_popup=new Object;
speed_up_popup[SOURCE]="../images/speed-up-popup.png";
speed_up_popup[X]=73;
speed_up_popup[Y]=6;
speed_up_popup[WIDTH]=29;
speed_up_popup[HEIGHT]=33;

var speed_down_popup=new Object;
speed_down_popup[SOURCE]="../images/speed-down-popup.png";
speed_down_popup[X]=6;
speed_down_popup[Y]=6;
speed_down_popup[WIDTH]=29;
speed_down_popup[HEIGHT]=33;

var play_popup=new Object;
play_popup[SOURCE]="../images/play-popup.png";
play_popup[X]=107;
play_popup[Y]=2;
play_popup[WIDTH]=72;
play_popup[HEIGHT]=42;

var pause_popup=new Object;
pause_popup[SOURCE]="../images/pause-popup.png";
pause_popup[X]=107;
pause_popup[Y]=2;
pause_popup[WIDTH]=72;
pause_popup[HEIGHT]=42;

var navigation_app_browse_map_simulation_background=new Object;
navigation_app_browse_map_simulation_background[SOURCE]="../images/navigation-app-browse-map-simulation-background.png";
navigation_app_browse_map_simulation_background[X]=0;
navigation_app_browse_map_simulation_background[Y]=0;
navigation_app_browse_map_simulation_background[WIDTH]=186;
navigation_app_browse_map_simulation_background[HEIGHT]=46;

