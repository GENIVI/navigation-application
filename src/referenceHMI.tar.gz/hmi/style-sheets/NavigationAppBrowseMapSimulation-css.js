/* This file is generated */
.pragma library
Qt.include("style-constants.js");

var speedUnit=new Object;
speedUnit[X]=87;
speedUnit[Y]=8;
speedUnit[WIDTH]=62;
speedUnit[HEIGHT]=30;
speedUnit[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
speedUnit[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
speedUnit[PIXELSIZE]=25;

var speedValue=new Object;
speedValue[X]=39;
speedValue[Y]=8;
speedValue[WIDTH]=32;
speedValue[HEIGHT]=30;
speedValue[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
speedValue[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
speedValue[PIXELSIZE]=25;

var speed_up_popup=new Object;
speed_up_popup[SOURCE]="../images/speed-up-popup.png";
speed_up_popup[X]=155;
speed_up_popup[Y]=6;
speed_up_popup[WIDTH]=29;
speed_up_popup[HEIGHT]=33;

var speed_down_popup=new Object;
speed_down_popup[SOURCE]="../images/speed-down-popup.png";
speed_down_popup[X]=2;
speed_down_popup[Y]=6;
speed_down_popup[WIDTH]=29;
speed_down_popup[HEIGHT]=33;

var play_popup=new Object;
play_popup[SOURCE]="../images/play-popup.png";
play_popup[X]=189;
play_popup[Y]=2;
play_popup[WIDTH]=72;
play_popup[HEIGHT]=42;

var pause_popup=new Object;
pause_popup[SOURCE]="../images/pause-popup.png";
pause_popup[X]=189;
pause_popup[Y]=2;
pause_popup[WIDTH]=72;
pause_popup[HEIGHT]=42;

var navigation_app_browse_map_simulation_background=new Object;
navigation_app_browse_map_simulation_background[SOURCE]="../images/navigation-app-browse-map-simulation-background.png";
navigation_app_browse_map_simulation_background[X]=0;
navigation_app_browse_map_simulation_background[Y]=0;
navigation_app_browse_map_simulation_background[WIDTH]=264;
navigation_app_browse_map_simulation_background[HEIGHT]=46;

