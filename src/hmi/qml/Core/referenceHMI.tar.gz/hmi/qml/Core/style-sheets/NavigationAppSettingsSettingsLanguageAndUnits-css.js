/* This file is generated */
.pragma library
Qt.include("style-constants.js");

var languagesTitle=new Object;
languagesTitle[X]=100;
languagesTitle[Y]=47;
languagesTitle[WIDTH]=156;
languagesTitle[HEIGHT]=30;
languagesTitle[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
languagesTitle[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
languagesTitle[PIXELSIZE]=25;

var unitsTitle=new Object;
unitsTitle[X]=331;
unitsTitle[Y]=47;
unitsTitle[WIDTH]=75;
unitsTitle[HEIGHT]=30;
unitsTitle[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
unitsTitle[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
unitsTitle[PIXELSIZE]=25;

var backText=new Object;
backText[X]=653;
backText[Y]=423;
backText[WIDTH]=104;
backText[HEIGHT]=44;
backText[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
backText[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
backText[PIXELSIZE]=38;

var unit_km=new Object;
unit_km[SOURCE]="Core/images/unit-km.png";
unit_km[X]=330;
unit_km[Y]=94;
unit_km[WIDTH]=100;
unit_km[HEIGHT]=60;

var unit_mile=new Object;
unit_mile[SOURCE]="Core/images/unit-mile.png";
unit_mile[X]=330;
unit_mile[Y]=167;
unit_mile[WIDTH]=100;
unit_mile[HEIGHT]=60;

var german_flag=new Object;
german_flag[SOURCE]="Core/images/german-flag.png";
german_flag[X]=98;
german_flag[Y]=164;
german_flag[WIDTH]=104;
german_flag[HEIGHT]=64;

var usa_flag=new Object;
usa_flag[SOURCE]="Core/images/usa-flag.png";
usa_flag[X]=98;
usa_flag[Y]=234;
usa_flag[WIDTH]=104;
usa_flag[HEIGHT]=64;

var french_flag=new Object;
french_flag[SOURCE]="Core/images/french-flag.png";
french_flag[X]=98;
french_flag[Y]=91;
french_flag[WIDTH]=104;
french_flag[HEIGHT]=64;

var japanese_flag=new Object;
japanese_flag[SOURCE]="Core/images/japanese-flag.png";
japanese_flag[X]=98;
japanese_flag[Y]=304;
japanese_flag[WIDTH]=104;
japanese_flag[HEIGHT]=64;

var back=new Object;
back[SOURCE]="Core/images/back.png";
back[X]=620;
back[Y]=415;
back[WIDTH]=160;
back[HEIGHT]=60;

var navigation_app_settings_language_and_units_background=new Object;
navigation_app_settings_language_and_units_background[SOURCE]="Core/images/navigation-app-settings-language-and-units-background.png";
navigation_app_settings_language_and_units_background[X]=0;
navigation_app_settings_language_and_units_background[Y]=0;
navigation_app_settings_language_and_units_background[WIDTH]=800;
navigation_app_settings_language_and_units_background[HEIGHT]=480;

