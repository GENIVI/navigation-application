/* This file is generated */
.pragma library
Qt.include("style-constants.js");

var maneuverAdvice=new Object;
maneuverAdvice[X]=6;
maneuverAdvice[Y]=42;
maneuverAdvice[WIDTH]=59;
maneuverAdvice[HEIGHT]=22;
maneuverAdvice[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
maneuverAdvice[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
maneuverAdvice[PIXELSIZE]=18;

var distancetomaneuverValue=new Object;
distancetomaneuverValue[X]=4;
distancetomaneuverValue[Y]=19;
distancetomaneuverValue[WIDTH]=78;
distancetomaneuverValue[HEIGHT]=24;
distancetomaneuverValue[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
distancetomaneuverValue[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
distancetomaneuverValue[PIXELSIZE]=20;

var maneuverIcon=new Object;
maneuverIcon[SOURCE]="Core/images/maneuverIcon.png";
maneuverIcon[X]=85;
maneuverIcon[Y]=3;
maneuverIcon[WIDTH]=64;
maneuverIcon[HEIGHT]=64;

var navigation_app_browse_map_guidance_background=new Object;
navigation_app_browse_map_guidance_background[SOURCE]="Core/images/navigation-app-browse-map-guidance-background.png";
navigation_app_browse_map_guidance_background[X]=0;
navigation_app_browse_map_guidance_background[Y]=0;
navigation_app_browse_map_guidance_background[WIDTH]=152;
navigation_app_browse_map_guidance_background[HEIGHT]=70;

