/* This file is generated */
.pragma library
Qt.include("style-constants.js");

var elementName=new Object;
elementName[X]=233;
elementName[Y]=69;
elementName[WIDTH]=190;
elementName[HEIGHT]=99;
elementName[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
elementName[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
elementName[PIXELSIZE]=28;

var elementTitle=new Object;
elementTitle[X]=87;
elementTitle[Y]=102;
elementTitle[WIDTH]=88;
elementTitle[HEIGHT]=35;
elementTitle[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
elementTitle[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
elementTitle[PIXELSIZE]=30;

var countryTitle=new Object;
countryTitle[X]=29;
countryTitle[Y]=37;
countryTitle[WIDTH]=145;
countryTitle[HEIGHT]=35;
countryTitle[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
countryTitle[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
countryTitle[PIXELSIZE]=30;

var countryValue=new Object;
countryValue[X]=234;
countryValue[Y]=39;
countryValue[WIDTH]=266;
countryValue[HEIGHT]=33;
countryValue[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
countryValue[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
countryValue[PIXELSIZE]=28;

var countryKeyboard=new Object;
countryKeyboard[SOURCE]="Core/images/countryKeyboard.png";
countryKeyboard[X]=187;
countryKeyboard[Y]=40;
countryKeyboard[WIDTH]=40;
countryKeyboard[HEIGHT]=30;

var cityTitle=new Object;
cityTitle[X]=30;
cityTitle[Y]=78;
cityTitle[WIDTH]=67;
cityTitle[HEIGHT]=35;
cityTitle[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
cityTitle[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
cityTitle[PIXELSIZE]=30;

var cityValue=new Object;
cityValue[X]=234;
cityValue[Y]=85;
cityValue[WIDTH]=266;
cityValue[HEIGHT]=33;
cityValue[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
cityValue[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
cityValue[PIXELSIZE]=28;

var cityKeyboard=new Object;
cityKeyboard[SOURCE]="Core/images/cityKeyboard.png";
cityKeyboard[X]=187;
cityKeyboard[Y]=82;
cityKeyboard[WIDTH]=40;
cityKeyboard[HEIGHT]=30;

var streetTitle=new Object;
streetTitle[X]=29;
streetTitle[Y]=123;
streetTitle[WIDTH]=115;
streetTitle[HEIGHT]=35;
streetTitle[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
streetTitle[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
streetTitle[PIXELSIZE]=30;

var streetValue=new Object;
streetValue[X]=234;
streetValue[Y]=129;
streetValue[WIDTH]=266;
streetValue[HEIGHT]=33;
streetValue[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
streetValue[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
streetValue[PIXELSIZE]=28;

var streetKeyboard=new Object;
streetKeyboard[SOURCE]="Core/images/streetKeyboard.png";
streetKeyboard[X]=187;
streetKeyboard[Y]=126;
streetKeyboard[WIDTH]=40;
streetKeyboard[HEIGHT]=30;

var numberTitle=new Object;
numberTitle[X]=29;
numberTitle[Y]=168;
numberTitle[WIDTH]=131;
numberTitle[HEIGHT]=35;
numberTitle[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
numberTitle[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
numberTitle[PIXELSIZE]=30;

var numberValue=new Object;
numberValue[X]=237;
numberValue[Y]=170;
numberValue[WIDTH]=171;
numberValue[HEIGHT]=33;
numberValue[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
numberValue[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
numberValue[PIXELSIZE]=28;

var numberKeyboard=new Object;
numberKeyboard[SOURCE]="Core/images/numberKeyboard.png";
numberKeyboard[X]=187;
numberKeyboard[Y]=171;
numberKeyboard[WIDTH]=40;
numberKeyboard[HEIGHT]=30;

var backText=new Object;
backText[X]=651;
backText[Y]=422;
backText[WIDTH]=104;
backText[HEIGHT]=44;
backText[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
backText[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
backText[PIXELSIZE]=38;

var back=new Object;
back[SOURCE]="Core/images/back.png";
back[X]=620;
back[Y]=415;
back[WIDTH]=160;
back[HEIGHT]=60;

var statusTitle=new Object;
statusTitle[X]=353;
statusTitle[Y]=221;
statusTitle[WIDTH]=93;
statusTitle[HEIGHT]=30;
statusTitle[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
statusTitle[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
statusTitle[PIXELSIZE]=25;

var statusValue=new Object;
statusValue[X]=302;
statusValue[Y]=255;
statusValue[WIDTH]=196;
statusValue[HEIGHT]=24;
statusValue[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
statusValue[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
statusValue[PIXELSIZE]=20;

var cancelText=new Object;
cancelText[X]=469;
cancelText[Y]=428;
cancelText[WIDTH]=121;
cancelText[HEIGHT]=35;
cancelText[TEXTCOLOR]=Qt.rgba(0.00, 0.00, 0.00, 1.00);
cancelText[STYLECOLOR]=Qt.rgba(0.00, 0.00, 0.00, 1.00);
cancelText[PIXELSIZE]=30;

var cancel=new Object;
cancel[SOURCE]="Core/images/cancel.png";
cancel[X]=448;
cancel[Y]=415;
cancel[WIDTH]=160;
cancel[HEIGHT]=60;

var calculate_curr=new Object;
calculate_curr[SOURCE]="Core/images/calculate_curr.png";
calculate_curr[X]=20;
calculate_curr[Y]=415;
calculate_curr[WIDTH]=60;
calculate_curr[HEIGHT]=60;

var location_input=new Object;
location_input[SOURCE]="Core/images/location-input.png";
location_input[X]=155;
location_input[Y]=415;
location_input[WIDTH]=60;
location_input[HEIGHT]=60;

var poi=new Object;
poi[SOURCE]="Core/images/poi.png";
poi[X]=235;
poi[Y]=415;
poi[WIDTH]=60;
poi[HEIGHT]=60;

var settings=new Object;
settings[SOURCE]="Core/images/settings.png";
settings[X]=372;
settings[Y]=415;
settings[WIDTH]=60;
settings[HEIGHT]=60;

var guidanceTitle=new Object;
guidanceTitle[X]=392;
guidanceTitle[Y]=289;
guidanceTitle[WIDTH]=132;
guidanceTitle[HEIGHT]=30;
guidanceTitle[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
guidanceTitle[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
guidanceTitle[PIXELSIZE]=25;

var startText=new Object;
startText[X]=425;
startText[Y]=340;
startText[WIDTH]=58;
startText[HEIGHT]=45;
startText[TEXTCOLOR]=Qt.rgba(0.00, 0.00, 0.00, 1.00);
startText[STYLECOLOR]=Qt.rgba(0.00, 0.00, 0.00, 1.00);
startText[PIXELSIZE]=38;

var guidance_start=new Object;
guidance_start[SOURCE]="Core/images/guidance-start.png";
guidance_start[X]=403;
guidance_start[Y]=333;
guidance_start[WIDTH]=100;
guidance_start[HEIGHT]=60;

var stopText=new Object;
stopText[X]=416;
stopText[Y]=341;
stopText[WIDTH]=74;
stopText[HEIGHT]=45;
stopText[TEXTCOLOR]=Qt.rgba(0.00, 0.00, 0.00, 1.00);
stopText[STYLECOLOR]=Qt.rgba(0.00, 0.00, 0.00, 1.00);
stopText[PIXELSIZE]=38;

var guidance_stop=new Object;
guidance_stop[SOURCE]="Core/images/guidance-stop.png";
guidance_stop[X]=403;
guidance_stop[Y]=333;
guidance_stop[WIDTH]=100;
guidance_stop[HEIGHT]=60;

var distanceTitle=new Object;
distanceTitle[X]=30;
distanceTitle[Y]=220;
distanceTitle[WIDTH]=124;
distanceTitle[HEIGHT]=30;
distanceTitle[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
distanceTitle[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
distanceTitle[PIXELSIZE]=25;

var distanceValue=new Object;
distanceValue[X]=30;
distanceValue[Y]=256;
distanceValue[WIDTH]=192;
distanceValue[HEIGHT]=42;
distanceValue[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
distanceValue[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
distanceValue[PIXELSIZE]=35;

var timeTitle=new Object;
timeTitle[X]=33;
timeTitle[Y]=300;
timeTitle[WIDTH]=60;
timeTitle[HEIGHT]=30;
timeTitle[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
timeTitle[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
timeTitle[PIXELSIZE]=25;

var timeValue=new Object;
timeValue[X]=30;
timeValue[Y]=330;
timeValue[WIDTH]=192;
timeValue[HEIGHT]=42;
timeValue[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
timeValue[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
timeValue[PIXELSIZE]=35;

var displayRouteTitle=new Object;
displayRouteTitle[X]=270;
displayRouteTitle[Y]=291;
displayRouteTitle[WIDTH]=102;
displayRouteTitle[HEIGHT]=29;
displayRouteTitle[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
displayRouteTitle[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
displayRouteTitle[PIXELSIZE]=25;

var show_route_on_map=new Object;
show_route_on_map[SOURCE]="Core/images/show-route-on-map.png";
show_route_on_map[X]=264;
show_route_on_map[Y]=333;
show_route_on_map[WIDTH]=100;
show_route_on_map[HEIGHT]=60;

var maneuver_delegate=new Object;
maneuver_delegate[X]=553;
maneuver_delegate[Y]=41;
maneuver_delegate[WIDTH]=208;
maneuver_delegate[HEIGHT]=21;
maneuver_delegate[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
maneuver_delegate[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
maneuver_delegate[PIXELSIZE]=18;

var maneuverArea=new Object;
maneuverArea[SOURCE]="Core/images/maneuverArea.png";
maneuverArea[X]=548;
maneuverArea[Y]=33;
maneuverArea[WIDTH]=220;
maneuverArea[HEIGHT]=175;

var crossroadZoom=new Object;
crossroadZoom[SOURCE]="Core/images/crossroadZoom.png";
crossroadZoom[X]=608;
crossroadZoom[Y]=239;
crossroadZoom[WIDTH]=160;
crossroadZoom[HEIGHT]=160;

var list_delegate=new Object;
list_delegate[X]=553;
list_delegate[Y]=41;
list_delegate[WIDTH]=208;
list_delegate[HEIGHT]=21;
list_delegate[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
list_delegate[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
list_delegate[PIXELSIZE]=18;

var prev_maneuver=new Object;
prev_maneuver[SOURCE]="Core/images/prev-maneuver.png";
prev_maneuver[X]=558;
prev_maneuver[Y]=266;
prev_maneuver[WIDTH]=42;
prev_maneuver[HEIGHT]=38;

var next_maneuver=new Object;
next_maneuver[SOURCE]="Core/images/next-maneuver.png";
next_maneuver[X]=558;
next_maneuver[Y]=335;
next_maneuver[WIDTH]=42;
next_maneuver[HEIGHT]=38;

var listArea=new Object;
listArea[SOURCE]="Core/images/listArea.png";
listArea[X]=548;
listArea[Y]=33;
listArea[WIDTH]=220;
listArea[HEIGHT]=175;

var keyboardArea=new Object;
keyboardArea[SOURCE]="Core/images/keyboardArea.png";
keyboardArea[X]=28;
keyboardArea[Y]=214;
keyboardArea[WIDTH]=744;
keyboardArea[HEIGHT]=188;

var locationInputBackground=new Object;
locationInputBackground[SOURCE]="Core/images/locationInputBackground.png";
locationInputBackground[X]=233;
locationInputBackground[Y]=40;
locationInputBackground[WIDTH]=295;
locationInputBackground[HEIGHT]=161;

var navigation_app_search_background=new Object;
navigation_app_search_background[SOURCE]="Core/images/navigation-app-search-background.png";
navigation_app_search_background[X]=0;
navigation_app_search_background[Y]=0;
navigation_app_search_background[WIDTH]=800;
navigation_app_search_background[HEIGHT]=480;

