/* This file is generated */
.pragma library
Qt.include("style-constants.js");

var exit=new Object;
exit[SOURCE]="Core/images/exit.png";
exit[X]=3;
exit[Y]=5;
exit[WIDTH]=22;
exit[HEIGHT]=22;

var maneuver_delegate=new Object;
maneuver_delegate[X]=1;
maneuver_delegate[Y]=45;
maneuver_delegate[WIDTH]=196;
maneuver_delegate[HEIGHT]=24;
maneuver_delegate[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
maneuver_delegate[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
maneuver_delegate[PIXELSIZE]=20;

var maneuver_area=new Object;
maneuver_area[SOURCE]="Core/images/maneuver-area.png";
maneuver_area[X]=0;
maneuver_area[Y]=30;
maneuver_area[WIDTH]=200;
maneuver_area[HEIGHT]=270;

var navigation_app_browse_map_maneuver_background=new Object;
navigation_app_browse_map_maneuver_background[SOURCE]="Core/images/navigation-app-browse-map-maneuver-background.png";
navigation_app_browse_map_maneuver_background[X]=0;
navigation_app_browse_map_maneuver_background[Y]=0;
navigation_app_browse_map_maneuver_background[WIDTH]=200;
navigation_app_browse_map_maneuver_background[HEIGHT]=300;

