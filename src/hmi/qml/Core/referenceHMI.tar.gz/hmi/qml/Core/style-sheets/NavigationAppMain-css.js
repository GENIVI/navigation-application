/* This file is generated */
.pragma library
Qt.include("style-constants.js");

var quitText=new Object;
quitText[X]=645;
quitText[Y]=424;
quitText[WIDTH]=93;
quitText[HEIGHT]=44;
quitText[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
quitText[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
quitText[PIXELSIZE]=38;

var quit=new Object;
quit[SOURCE]="Core/images/quit.png";
quit[X]=620;
quit[Y]=415;
quit[WIDTH]=160;
quit[HEIGHT]=60;

var mapviewText=new Object;
mapviewText[X]=563;
mapviewText[Y]=153;
mapviewText[WIDTH]=50;
mapviewText[HEIGHT]=28;
mapviewText[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
mapviewText[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
mapviewText[PIXELSIZE]=23;

var select_mapview=new Object;
select_mapview[SOURCE]="Core/images/select-mapview.png";
select_mapview[X]=518;
select_mapview[Y]=46;
select_mapview[WIDTH]=144;
select_mapview[HEIGHT]=104;

var poiText=new Object;
poiText[X]=139;
poiText[Y]=327;
poiText[WIDTH]=39;
poiText[HEIGHT]=28;
poiText[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
poiText[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
poiText[PIXELSIZE]=23;

var select_poi=new Object;
select_poi[SOURCE]="Core/images/select-poi.png";
select_poi[X]=88;
select_poi[Y]=222;
select_poi[WIDTH]=144;
select_poi[HEIGHT]=104;

var tripText=new Object;
tripText[X]=618;
tripText[Y]=326;
tripText[WIDTH]=51;
tripText[HEIGHT]=28;
tripText[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
tripText[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
tripText[PIXELSIZE]=23;

var select_trip=new Object;
select_trip[SOURCE]="Core/images/select-trip.png";
select_trip[X]=571;
select_trip[Y]=222;
select_trip[WIDTH]=144;
select_trip[HEIGHT]=104;

var settingsText=new Object;
settingsText[X]=374;
settingsText[Y]=278;
settingsText[WIDTH]=64;
settingsText[HEIGHT]=26;
settingsText[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
settingsText[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
settingsText[PIXELSIZE]=23;

var select_settings=new Object;
select_settings[SOURCE]="Core/images/select-settings.png";
select_settings[X]=330;
select_settings[Y]=166;
select_settings[WIDTH]=144;
select_settings[HEIGHT]=104;

var navigationText=new Object;
navigationText[X]=187;
navigationText[Y]=153;
navigationText[WIDTH]=55;
navigationText[HEIGHT]=28;
navigationText[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
navigationText[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
navigationText[PIXELSIZE]=23;

var select_navigation=new Object;
select_navigation[SOURCE]="Core/images/select-navigation.png";
select_navigation[X]=141;
select_navigation[Y]=46;
select_navigation[WIDTH]=144;
select_navigation[HEIGHT]=104;

var navigation_app_main_background=new Object;
navigation_app_main_background[SOURCE]="Core/images/navigation-app-main-background.png";
navigation_app_main_background[X]=0;
navigation_app_main_background[Y]=0;
navigation_app_main_background[WIDTH]=800;
navigation_app_main_background[HEIGHT]=480;

