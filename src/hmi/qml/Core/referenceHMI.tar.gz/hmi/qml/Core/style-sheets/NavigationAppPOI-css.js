/* This file is generated */
.pragma library
Qt.include("style-constants.js");

var backText=new Object;
backText[X]=648;
backText[Y]=422;
backText[WIDTH]=104;
backText[HEIGHT]=44;
backText[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
backText[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
backText[PIXELSIZE]=38;

var back=new Object;
back[SOURCE]="Core/images/back.png";
back[X]=620;
back[Y]=415;
back[WIDTH]=160;
back[HEIGHT]=60;

var select_display_on_map=new Object;
select_display_on_map[SOURCE]="Core/images/select-display-on-map.png";
select_display_on_map[X]=258;
select_display_on_map[Y]=415;
select_display_on_map[WIDTH]=100;
select_display_on_map[HEIGHT]=60;

var select_reroute=new Object;
select_reroute[SOURCE]="Core/images/select-reroute.png";
select_reroute[X]=139;
select_reroute[Y]=415;
select_reroute[WIDTH]=100;
select_reroute[HEIGHT]=60;

var select_search=new Object;
select_search[SOURCE]="Core/images/select-search.png";
select_search[X]=20;
select_search[Y]=415;
select_search[WIDTH]=100;
select_search[HEIGHT]=60;

var searchResultValue=new Object;
searchResultValue[X]=553;
searchResultValue[Y]=41;
searchResultValue[WIDTH]=210;
searchResultValue[HEIGHT]=24;
searchResultValue[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
searchResultValue[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
searchResultValue[PIXELSIZE]=20;

var searchResultList=new Object;
searchResultList[SOURCE]="Core/images/searchResultList.png";
searchResultList[X]=548;
searchResultList[Y]=33;
searchResultList[WIDTH]=220;
searchResultList[HEIGHT]=175;

var categoryKeyboard=new Object;
categoryKeyboard[SOURCE]="Core/images/categoryKeyboard.png";
categoryKeyboard[X]=29;
categoryKeyboard[Y]=118;
categoryKeyboard[WIDTH]=40;
categoryKeyboard[HEIGHT]=30;

var categoryFrame=new Object;
categoryFrame[SOURCE]="Core/images/categoryFrame.png";
categoryFrame[X]=73;
categoryFrame[Y]=116;
categoryFrame[WIDTH]=281;
categoryFrame[HEIGHT]=34;

var poiName=new Object;
poiName[X]=101;
poiName[Y]=34;
poiName[WIDTH]=190;
poiName[HEIGHT]=66;
poiName[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
poiName[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
poiName[PIXELSIZE]=28;

var categoryValue=new Object;
categoryValue[X]=75;
categoryValue[Y]=116;
categoryValue[WIDTH]=273;
categoryValue[HEIGHT]=35;
categoryValue[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
categoryValue[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
categoryValue[PIXELSIZE]=30;

var poiKeyboard=new Object;
poiKeyboard[SOURCE]="Core/images/poiKeyboard.png";
poiKeyboard[X]=29;
poiKeyboard[Y]=171;
poiKeyboard[WIDTH]=40;
poiKeyboard[HEIGHT]=30;

var poiFrame=new Object;
poiFrame[SOURCE]="Core/images/poiFrame.png";
poiFrame[X]=73;
poiFrame[Y]=168;
poiFrame[WIDTH]=281;
poiFrame[HEIGHT]=34;

var poiValue=new Object;
poiValue[X]=75;
poiValue[Y]=169;
poiValue[WIDTH]=273;
poiValue[HEIGHT]=35;
poiValue[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
poiValue[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
poiValue[PIXELSIZE]=30;

var selectedValueTitle=new Object;
selectedValueTitle[X]=384;
selectedValueTitle[Y]=157;
selectedValueTitle[WIDTH]=129;
selectedValueTitle[HEIGHT]=29;
selectedValueTitle[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
selectedValueTitle[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
selectedValueTitle[PIXELSIZE]=25;

var selectedValue=new Object;
selectedValue[X]=365;
selectedValue[Y]=32;
selectedValue[WIDTH]=165;
selectedValue[HEIGHT]=100;
selectedValue[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
selectedValue[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
selectedValue[PIXELSIZE]=21;

var settings=new Object;
settings[SOURCE]="Core/images/settings.png";
settings[X]=388;
settings[Y]=415;
settings[WIDTH]=60;
settings[HEIGHT]=60;

var keyboardArea=new Object;
keyboardArea[SOURCE]="Core/images/keyboardArea.png";
keyboardArea[X]=28;
keyboardArea[Y]=214;
keyboardArea[WIDTH]=744;
keyboardArea[HEIGHT]=188;

var navigation_app_poi_background=new Object;
navigation_app_poi_background[SOURCE]="Core/images/navigation-app-poi-background.png";
navigation_app_poi_background[X]=0;
navigation_app_poi_background[Y]=0;
navigation_app_poi_background[WIDTH]=800;
navigation_app_poi_background[HEIGHT]=480;

