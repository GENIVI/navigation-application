/* This file is generated */
.pragma library
Qt.include("style-constants.js");

var button_keyboard=new Object;
button_keyboard[SOURCE]="Core/images/button-keyboard.png";
button_keyboard[X]=0;
button_keyboard[Y]=0;
button_keyboard[WIDTH]=50;
button_keyboard[HEIGHT]=50;

