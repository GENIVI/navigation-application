/* This file is generated */
.pragma library
Qt.include("style-constants.js");

var scrollup=new Object;
scrollup[SOURCE]="Core/images/scrollup.png";
scrollup[X]=27;
scrollup[Y]=1;
scrollup[WIDTH]=29;
scrollup[HEIGHT]=22;

var scrolldown=new Object;
scrolldown[SOURCE]="Core/images/scrolldown.png";
scrolldown[X]=26;
scrolldown[Y]=62;
scrolldown[WIDTH]=30;
scrolldown[HEIGHT]=22;

var scrollleft=new Object;
scrollleft[SOURCE]="Core/images/scrollleft.png";
scrollleft[X]=0;
scrollleft[Y]=29;
scrollleft[WIDTH]=22;
scrollleft[HEIGHT]=29;

var scrollright=new Object;
scrollright[SOURCE]="Core/images/scrollright.png";
scrollright[X]=61;
scrollright[Y]=28;
scrollright[WIDTH]=22;
scrollright[HEIGHT]=30;

var navigation_app_browse_map_scroll_background=new Object;
navigation_app_browse_map_scroll_background[SOURCE]="Core/images/navigation-app-browse-map-scroll-background.png";
navigation_app_browse_map_scroll_background[X]=0;
navigation_app_browse_map_scroll_background[Y]=-1;
navigation_app_browse_map_scroll_background[WIDTH]=84;
navigation_app_browse_map_scroll_background[HEIGHT]=84;

