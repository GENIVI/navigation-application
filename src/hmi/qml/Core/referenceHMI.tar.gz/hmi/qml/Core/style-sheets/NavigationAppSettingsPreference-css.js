/* This file is generated */
.pragma library
Qt.include("style-constants.js");

var costModelValue=new Object;
costModelValue[X]=119;
costModelValue[Y]=134;
costModelValue[WIDTH]=147;
costModelValue[HEIGHT]=38;
costModelValue[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
costModelValue[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
costModelValue[PIXELSIZE]=31;

var ferriesText=new Object;
ferriesText[X]=330;
ferriesText[Y]=137;
ferriesText[WIDTH]=131;
ferriesText[HEIGHT]=37;
ferriesText[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
ferriesText[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
ferriesText[PIXELSIZE]=31;

var motorWaysText=new Object;
motorWaysText[X]=330;
motorWaysText[Y]=287;
motorWaysText[WIDTH]=202;
motorWaysText[HEIGHT]=37;
motorWaysText[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
motorWaysText[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
motorWaysText[PIXELSIZE]=31;

var tollRoadsText=new Object;
tollRoadsText[X]=330;
tollRoadsText[Y]=208;
tollRoadsText[WIDTH]=197;
tollRoadsText[HEIGHT]=37;
tollRoadsText[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
tollRoadsText[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
tollRoadsText[PIXELSIZE]=31;

var routingPreferencesTitle=new Object;
routingPreferencesTitle[X]=331;
routingPreferencesTitle[Y]=47;
routingPreferencesTitle[WIDTH]=302;
routingPreferencesTitle[HEIGHT]=30;
routingPreferencesTitle[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
routingPreferencesTitle[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
routingPreferencesTitle[PIXELSIZE]=25;

var costModelTitle=new Object;
costModelTitle[X]=100;
costModelTitle[Y]=47;
costModelTitle[WIDTH]=167;
costModelTitle[HEIGHT]=30;
costModelTitle[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
costModelTitle[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
costModelTitle[PIXELSIZE]=25;

var cost_model=new Object;
cost_model[SOURCE]="Core/images/cost-model.png";
cost_model[X]=100;
cost_model[Y]=124;
cost_model[WIDTH]=180;
cost_model[HEIGHT]=60;

var allow_tollRoads=new Object;
allow_tollRoads[SOURCE]="Core/images/allow-tollRoads.png";
allow_tollRoads[X]=560;
allow_tollRoads[Y]=199;
allow_tollRoads[WIDTH]=50;
allow_tollRoads[HEIGHT]=60;

var avoid_tollRoads=new Object;
avoid_tollRoads[SOURCE]="Core/images/avoid-tollRoads.png";
avoid_tollRoads[X]=610;
avoid_tollRoads[Y]=199;
avoid_tollRoads[WIDTH]=50;
avoid_tollRoads[HEIGHT]=60;

var allow_motorways=new Object;
allow_motorways[SOURCE]="Core/images/allow-motorways.png";
allow_motorways[X]=560;
allow_motorways[Y]=275;
allow_motorways[WIDTH]=50;
allow_motorways[HEIGHT]=60;

var avoid_motorways=new Object;
avoid_motorways[SOURCE]="Core/images/avoid-motorways.png";
avoid_motorways[X]=610;
avoid_motorways[Y]=275;
avoid_motorways[WIDTH]=50;
avoid_motorways[HEIGHT]=60;

var allow_ferries=new Object;
allow_ferries[SOURCE]="Core/images/allow-ferries.png";
allow_ferries[X]=560;
allow_ferries[Y]=125;
allow_ferries[WIDTH]=50;
allow_ferries[HEIGHT]=60;

var avoid_ferries=new Object;
avoid_ferries[SOURCE]="Core/images/avoid-ferries.png";
avoid_ferries[X]=610;
avoid_ferries[Y]=125;
avoid_ferries[WIDTH]=50;
avoid_ferries[HEIGHT]=60;

var backText=new Object;
backText[X]=655;
backText[Y]=422;
backText[WIDTH]=104;
backText[HEIGHT]=44;
backText[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
backText[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
backText[PIXELSIZE]=38;

var back=new Object;
back[SOURCE]="Core/images/back.png";
back[X]=621;
back[Y]=415;
back[WIDTH]=160;
back[HEIGHT]=60;

var navigation_app_settings_preference_background=new Object;
navigation_app_settings_preference_background[SOURCE]="Core/images/navigation-app-settings-preference-background.png";
navigation_app_settings_preference_background[X]=0;
navigation_app_settings_preference_background[Y]=0;
navigation_app_settings_preference_background[WIDTH]=800;
navigation_app_settings_preference_background[HEIGHT]=480;

