/* This file is generated */
.pragma library
Qt.include("style-constants.js");

var showroomTitle=new Object;
showroomTitle[X]=295;
showroomTitle[Y]=73;
showroomTitle[WIDTH]=159;
showroomTitle[HEIGHT]=29;
showroomTitle[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
showroomTitle[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
showroomTitle[PIXELSIZE]=25;

var showroom_disable=new Object;
showroom_disable[SOURCE]="Core/images/showroom-disable.png";
showroom_disable[X]=340;
showroom_disable[Y]=127;
showroom_disable[WIDTH]=65;
showroom_disable[HEIGHT]=63;

var showroom_enable=new Object;
showroom_enable[SOURCE]="Core/images/showroom-enable.png";
showroom_enable[X]=340;
showroom_enable[Y]=127;
showroom_enable[WIDTH]=65;
showroom_enable[HEIGHT]=63;

var simulationTitle=new Object;
simulationTitle[X]=94;
simulationTitle[Y]=72;
simulationTitle[WIDTH]=154;
simulationTitle[HEIGHT]=30;
simulationTitle[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
simulationTitle[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
simulationTitle[PIXELSIZE]=25;

var simu_mode_disable=new Object;
simu_mode_disable[SOURCE]="Core/images/simu-mode-disable.png";
simu_mode_disable[X]=136;
simu_mode_disable[Y]=127;
simu_mode_disable[WIDTH]=65;
simu_mode_disable[HEIGHT]=63;

var simu_mode_enable=new Object;
simu_mode_enable[SOURCE]="Core/images/simu-mode-enable.png";
simu_mode_enable[X]=136;
simu_mode_enable[Y]=127;
simu_mode_enable[WIDTH]=65;
simu_mode_enable[HEIGHT]=63;

var backText=new Object;
backText[X]=630;
backText[Y]=404;
backText[WIDTH]=128;
backText[HEIGHT]=49;
backText[TEXTCOLOR]=Qt.rgba(0.25, 0.39, 0.59, 1.00);
backText[STYLECOLOR]=Qt.rgba(0.25, 0.39, 0.59, 1.00);
backText[PIXELSIZE]=38;

var back=new Object;
back[SOURCE]="Core/images/back.png";
back[X]=601;
back[Y]=400;
back[WIDTH]=180;
back[HEIGHT]=60;

var preferencesText=new Object;
preferencesText[X]=25;
preferencesText[Y]=408;
preferencesText[WIDTH]=248;
preferencesText[HEIGHT]=45;
preferencesText[TEXTCOLOR]=Qt.rgba(0.00, 0.00, 0.00, 1.00);
preferencesText[STYLECOLOR]=Qt.rgba(0.00, 0.00, 0.00, 1.00);
preferencesText[PIXELSIZE]=38;

var preferences=new Object;
preferences[SOURCE]="Core/images/preferences.png";
preferences[X]=20;
preferences[Y]=400;
preferences[WIDTH]=260;
preferences[HEIGHT]=60;

var languageAndUnitText=new Object;
languageAndUnitText[X]=314;
languageAndUnitText[Y]=407;
languageAndUnitText[WIDTH]=249;
languageAndUnitText[HEIGHT]=45;
languageAndUnitText[TEXTCOLOR]=Qt.rgba(0.00, 0.00, 0.00, 1.00);
languageAndUnitText[STYLECOLOR]=Qt.rgba(0.00, 0.00, 0.00, 1.00);
languageAndUnitText[PIXELSIZE]=38;

var languageAndUnit=new Object;
languageAndUnit[SOURCE]="Core/images/languageAndUnit.png";
languageAndUnit[X]=310;
languageAndUnit[Y]=400;
languageAndUnit[WIDTH]=260;
languageAndUnit[HEIGHT]=60;

var navigation_app_settings_background=new Object;
navigation_app_settings_background[SOURCE]="Core/images/navigation-app-settings-background.png";
navigation_app_settings_background[X]=0;
navigation_app_settings_background[Y]=0;
navigation_app_settings_background[WIDTH]=800;
navigation_app_settings_background[HEIGHT]=480;

