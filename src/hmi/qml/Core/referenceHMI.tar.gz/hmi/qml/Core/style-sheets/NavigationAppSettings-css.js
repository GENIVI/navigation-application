/* This file is generated */
.pragma library
Qt.include("style-constants.js");

var languagesTitle=new Object;
languagesTitle[X]=390;
languagesTitle[Y]=36;
languagesTitle[WIDTH]=156;
languagesTitle[HEIGHT]=30;
languagesTitle[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
languagesTitle[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
languagesTitle[PIXELSIZE]=25;

var japanese_flag=new Object;
japanese_flag[SOURCE]="Core/images/japanese-flag.png";
japanese_flag[X]=431;
japanese_flag[Y]=266;
japanese_flag[WIDTH]=71;
japanese_flag[HEIGHT]=46;

var french_flag=new Object;
french_flag[SOURCE]="Core/images/french-flag.png";
french_flag[X]=431;
french_flag[Y]=207;
french_flag[WIDTH]=71;
french_flag[HEIGHT]=46;

var usa_flag=new Object;
usa_flag[SOURCE]="Core/images/usa-flag.png";
usa_flag[X]=431;
usa_flag[Y]=146;
usa_flag[WIDTH]=71;
usa_flag[HEIGHT]=46;

var german_flag=new Object;
german_flag[SOURCE]="Core/images/german-flag.png";
german_flag[X]=431;
german_flag[Y]=83;
german_flag[WIDTH]=71;
german_flag[HEIGHT]=46;

var costModelTitle=new Object;
costModelTitle[X]=593;
costModelTitle[Y]=223;
costModelTitle[WIDTH]=167;
costModelTitle[HEIGHT]=30;
costModelTitle[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
costModelTitle[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
costModelTitle[PIXELSIZE]=25;

var costModelValue=new Object;
costModelValue[X]=630;
costModelValue[Y]=271;
costModelValue[WIDTH]=119;
costModelValue[HEIGHT]=28;
costModelValue[TEXTCOLOR]=Qt.rgba(0.00, 0.00, 0.00, 1.00);
costModelValue[STYLECOLOR]=Qt.rgba(0.00, 0.00, 0.00, 1.00);
costModelValue[PIXELSIZE]=24;

var cost_model=new Object;
cost_model[SOURCE]="Core/images/cost-model.png";
cost_model[X]=622;
cost_model[Y]=265;
cost_model[WIDTH]=138;
cost_model[HEIGHT]=38;

var unitsTitle=new Object;
unitsTitle[X]=617;
unitsTitle[Y]=37;
unitsTitle[WIDTH]=75;
unitsTitle[HEIGHT]=30;
unitsTitle[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
unitsTitle[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
unitsTitle[PIXELSIZE]=25;

var unit_mile=new Object;
unit_mile[SOURCE]="Core/images/unit-mile.png";
unit_mile[X]=617;
unit_mile[Y]=141;
unit_mile[WIDTH]=71;
unit_mile[HEIGHT]=38;

var unit_km=new Object;
unit_km[SOURCE]="Core/images/unit-km.png";
unit_km[X]=617;
unit_km[Y]=84;
unit_km[WIDTH]=71;
unit_km[HEIGHT]=38;

var showroomTitle=new Object;
showroomTitle[X]=150;
showroomTitle[Y]=301;
showroomTitle[WIDTH]=138;
showroomTitle[HEIGHT]=25;
showroomTitle[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
showroomTitle[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
showroomTitle[PIXELSIZE]=22;

var showroom_disable=new Object;
showroom_disable[SOURCE]="Core/images/showroom-disable.png";
showroom_disable[X]=300;
showroom_disable[Y]=297;
showroom_disable[WIDTH]=34;
showroom_disable[HEIGHT]=34;

var showroom_enable=new Object;
showroom_enable[SOURCE]="Core/images/showroom-enable.png";
showroom_enable[X]=300;
showroom_enable[Y]=297;
showroom_enable[WIDTH]=34;
showroom_enable[HEIGHT]=34;

var simulationTitle=new Object;
simulationTitle[X]=156;
simulationTitle[Y]=348;
simulationTitle[WIDTH]=133;
simulationTitle[HEIGHT]=25;
simulationTitle[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
simulationTitle[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
simulationTitle[PIXELSIZE]=22;

var simu_mode_disable=new Object;
simu_mode_disable[SOURCE]="Core/images/simu-mode-disable.png";
simu_mode_disable[X]=300;
simu_mode_disable[Y]=346;
simu_mode_disable[WIDTH]=34;
simu_mode_disable[HEIGHT]=34;

var simu_mode_enable=new Object;
simu_mode_enable[SOURCE]="Core/images/simu-mode-enable.png";
simu_mode_enable[X]=300;
simu_mode_enable[Y]=346;
simu_mode_enable[WIDTH]=34;
simu_mode_enable[HEIGHT]=34;

var backText=new Object;
backText[X]=642;
backText[Y]=423;
backText[WIDTH]=128;
backText[HEIGHT]=49;
backText[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
backText[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
backText[PIXELSIZE]=38;

var back=new Object;
back[SOURCE]="Core/images/back.png";
back[X]=620;
back[Y]=416;
back[WIDTH]=160;
back[HEIGHT]=60;

var routingPreferencesTitle=new Object;
routingPreferencesTitle[X]=34;
routingPreferencesTitle[Y]=34;
routingPreferencesTitle[WIDTH]=302;
routingPreferencesTitle[HEIGHT]=30;
routingPreferencesTitle[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
routingPreferencesTitle[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
routingPreferencesTitle[PIXELSIZE]=25;

var tollRoadsText=new Object;
tollRoadsText[X]=91;
tollRoadsText[Y]=155;
tollRoadsText[WIDTH]=139;
tollRoadsText[HEIGHT]=25;
tollRoadsText[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
tollRoadsText[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
tollRoadsText[PIXELSIZE]=22;

var allow_tollRoads=new Object;
allow_tollRoads[SOURCE]="Core/images/allow-tollRoads.png";
allow_tollRoads[X]=259;
allow_tollRoads[Y]=145;
allow_tollRoads[WIDTH]=38;
allow_tollRoads[HEIGHT]=50;

var avoid_tollRoads=new Object;
avoid_tollRoads[SOURCE]="Core/images/avoid-tollRoads.png";
avoid_tollRoads[X]=297;
avoid_tollRoads[Y]=146;
avoid_tollRoads[WIDTH]=38;
avoid_tollRoads[HEIGHT]=50;

var motorWaysText=new Object;
motorWaysText[X]=88;
motorWaysText[Y]=215;
motorWaysText[WIDTH]=141;
motorWaysText[HEIGHT]=25;
motorWaysText[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
motorWaysText[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
motorWaysText[PIXELSIZE]=22;

var allow_motorways=new Object;
allow_motorways[SOURCE]="Core/images/allow-motorways.png";
allow_motorways[X]=260;
allow_motorways[Y]=204;
allow_motorways[WIDTH]=38;
allow_motorways[HEIGHT]=50;

var avoid_motorways=new Object;
avoid_motorways[SOURCE]="Core/images/avoid-motorways.png";
avoid_motorways[X]=298;
avoid_motorways[Y]=205;
avoid_motorways[WIDTH]=38;
avoid_motorways[HEIGHT]=50;

var ferriesText=new Object;
ferriesText[X]=144;
ferriesText[Y]=97;
ferriesText[WIDTH]=91;
ferriesText[HEIGHT]=25;
ferriesText[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
ferriesText[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
ferriesText[PIXELSIZE]=22;

var avoid_ferries=new Object;
avoid_ferries[SOURCE]="Core/images/avoid-ferries.png";
avoid_ferries[X]=296;
avoid_ferries[Y]=85;
avoid_ferries[WIDTH]=38;
avoid_ferries[HEIGHT]=50;

var allow_ferries=new Object;
allow_ferries[SOURCE]="Core/images/allow-ferries.png";
allow_ferries[X]=258;
allow_ferries[Y]=84;
allow_ferries[WIDTH]=38;
allow_ferries[HEIGHT]=50;

var navigation_app_settings_background=new Object;
navigation_app_settings_background[SOURCE]="Core/images/navigation-app-settings-background.png";
navigation_app_settings_background[X]=0;
navigation_app_settings_background[Y]=0;
navigation_app_settings_background[WIDTH]=800;
navigation_app_settings_background[HEIGHT]=480;

