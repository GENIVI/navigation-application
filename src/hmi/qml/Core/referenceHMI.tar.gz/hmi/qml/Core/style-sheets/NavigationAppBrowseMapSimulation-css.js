/* This file is generated */
.pragma library
Qt.include("style-constants.js");

var simulation_off_popup=new Object;
simulation_off_popup[SOURCE]="Core/images/simulation-off-popup.png";
simulation_off_popup[X]=100;
simulation_off_popup[Y]=2;
simulation_off_popup[WIDTH]=72;
simulation_off_popup[HEIGHT]=42;

var simulation_on_popup=new Object;
simulation_on_popup[SOURCE]="Core/images/simulation-on-popup.png";
simulation_on_popup[X]=100;
simulation_on_popup[Y]=2;
simulation_on_popup[WIDTH]=72;
simulation_on_popup[HEIGHT]=42;

var speedValue_popup=new Object;
speedValue_popup[X]=33;
speedValue_popup[Y]=8;
speedValue_popup[WIDTH]=35;
speedValue_popup[HEIGHT]=24;
speedValue_popup[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
speedValue_popup[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
speedValue_popup[PIXELSIZE]=20;

var speed_up_popup=new Object;
speed_up_popup[SOURCE]="Core/images/speed-up-popup.png";
speed_up_popup[X]=69;
speed_up_popup[Y]=4;
speed_up_popup[WIDTH]=29;
speed_up_popup[HEIGHT]=33;

var speed_down_popup=new Object;
speed_down_popup[SOURCE]="Core/images/speed-down-popup.png";
speed_down_popup[X]=2;
speed_down_popup[Y]=4;
speed_down_popup[WIDTH]=29;
speed_down_popup[HEIGHT]=33;

var play_popup=new Object;
play_popup[SOURCE]="Core/images/play-popup.png";
play_popup[X]=176;
play_popup[Y]=2;
play_popup[WIDTH]=72;
play_popup[HEIGHT]=42;

var pause_popup=new Object;
pause_popup[SOURCE]="Core/images/pause-popup.png";
pause_popup[X]=176;
pause_popup[Y]=2;
pause_popup[WIDTH]=72;
pause_popup[HEIGHT]=42;

var navigation_app_browse_map_simulation_background=new Object;
navigation_app_browse_map_simulation_background[SOURCE]="Core/images/navigation-app-browse-map-simulation-background.png";
navigation_app_browse_map_simulation_background[X]=0;
navigation_app_browse_map_simulation_background[Y]=0;
navigation_app_browse_map_simulation_background[WIDTH]=250;
navigation_app_browse_map_simulation_background[HEIGHT]=46;

