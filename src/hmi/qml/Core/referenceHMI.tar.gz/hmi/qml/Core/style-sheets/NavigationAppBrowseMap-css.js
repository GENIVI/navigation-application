/* This file is generated */
.pragma library
Qt.include("style-constants.js");

var settings_area=new Object;
settings_area[SOURCE]="Core/images/settings-area.png";
settings_area[X]=271;
settings_area[Y]=125;
settings_area[WIDTH]=300;
settings_area[HEIGHT]=200;

var maneuver_area=new Object;
maneuver_area[SOURCE]="Core/images/maneuver-area.png";
maneuver_area[X]=6;
maneuver_area[Y]=89;
maneuver_area[WIDTH]=200;
maneuver_area[HEIGHT]=300;

var route_area=new Object;
route_area[SOURCE]="Core/images/route-area.png";
route_area[X]=6;
route_area[Y]=164;
route_area[WIDTH]=94;
route_area[HEIGHT]=140;

var bottom_area=new Object;
bottom_area[SOURCE]="Core/images/bottom-area.png";
bottom_area[X]=0;
bottom_area[Y]=416;
bottom_area[WIDTH]=800;
bottom_area[HEIGHT]=64;

var guidance_area=new Object;
guidance_area[SOURCE]="Core/images/guidance-area.png";
guidance_area[X]=6;
guidance_area[Y]=319;
guidance_area[WIDTH]=152;
guidance_area[HEIGHT]=70;

var top_area=new Object;
top_area[SOURCE]="Core/images/top-area.png";
top_area[X]=0;
top_area[Y]=0;
top_area[WIDTH]=800;
top_area[HEIGHT]=64;

var scroll_area=new Object;
scroll_area[SOURCE]="Core/images/scroll-area.png";
scroll_area[X]=709;
scroll_area[Y]=71;
scroll_area[WIDTH]=84;
scroll_area[HEIGHT]=84;

var simulation_area=new Object;
simulation_area[SOURCE]="Core/images/simulation-area.png";
simulation_area[X]=543;
simulation_area[Y]=363;
simulation_area[WIDTH]=250;
simulation_area[HEIGHT]=46;

var menu=new Object;
menu[SOURCE]="Core/images/menu.png";
menu[X]=0;
menu[Y]=0;
menu[WIDTH]=800;
menu[HEIGHT]=480;

