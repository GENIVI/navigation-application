/* This file is generated */
.pragma library
Qt.include("style-constants.js");

var select_search_for_refill_in_top=new Object;
select_search_for_refill_in_top[SOURCE]="Core/images/select-search-for-refill-in-top.png";
select_search_for_refill_in_top[X]=177;
select_search_for_refill_in_top[Y]=10;
select_search_for_refill_in_top[WIDTH]=45;
select_search_for_refill_in_top[HEIGHT]=42;

var roadaftermaneuverValue=new Object;
roadaftermaneuverValue[X]=289;
roadaftermaneuverValue[Y]=16;
roadaftermaneuverValue[WIDTH]=329;
roadaftermaneuverValue[HEIGHT]=32;
roadaftermaneuverValue[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
roadaftermaneuverValue[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
roadaftermaneuverValue[PIXELSIZE]=26;

var speedValue=new Object;
speedValue[X]=675;
speedValue[Y]=17;
speedValue[WIDTH]=32;
speedValue[HEIGHT]=30;
speedValue[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
speedValue[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
speedValue[PIXELSIZE]=25;

var speedUnit=new Object;
speedUnit[X]=717;
speedUnit[Y]=17;
speedUnit[WIDTH]=62;
speedUnit[HEIGHT]=30;
speedUnit[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
speedUnit[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
speedUnit[PIXELSIZE]=25;

var time_in_top=new Object;
time_in_top[X]=13;
time_in_top[Y]=18;
time_in_top[WIDTH]=68;
time_in_top[HEIGHT]=28;
time_in_top[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
time_in_top[STYLECOLOR]=Qt.rgba(1.00, 1.00, 0.00, 1.00);
time_in_top[PIXELSIZE]=24;

var fsamessageText=new Object;
fsamessageText[X]=111;
fsamessageText[Y]=18;
fsamessageText[WIDTH]=58;
fsamessageText[HEIGHT]=28;
fsamessageText[TEXTCOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
fsamessageText[STYLECOLOR]=Qt.rgba(1.00, 1.00, 1.00, 1.00);
fsamessageText[PIXELSIZE]=24;

var navigation_app_browse_map_top_background=new Object;
navigation_app_browse_map_top_background[SOURCE]="Core/images/navigation-app-browse-map-top-background.png";
navigation_app_browse_map_top_background[X]=0;
navigation_app_browse_map_top_background[Y]=0;
navigation_app_browse_map_top_background[WIDTH]=800;
navigation_app_browse_map_top_background[HEIGHT]=64;

